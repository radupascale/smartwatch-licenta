var dir_70c5cd4c8bba287fe799894cc0903ca4 =
[
    [ "algorithm", "dir_19b53f07f52837a342947cc20e6d978f.html", "dir_19b53f07f52837a342947cc20e6d978f" ],
    [ "MAX30102", "dir_d4a9a7556cca61907ce453116086a23a.html", "dir_d4a9a7556cca61907ce453116086a23a" ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ]
];