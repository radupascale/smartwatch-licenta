var _r_d117___a_r_d_u_i_n_o_8ino =
[
    [ "MAX_BRIGHTNESS", "_r_d117___a_r_d_u_i_n_o_8ino.html#a2134a5a06f0865c945543a1f07eba387", null ],
    [ "loop", "_r_d117___a_r_d_u_i_n_o_8ino.html#afe461d27b9c48d5921c00d521181f12f", null ],
    [ "setup", "_r_d117___a_r_d_u_i_n_o_8ino.html#a4fc01d736fe50cf5b977f755b675f11d", null ],
    [ "aun_ir_buffer", "_r_d117___a_r_d_u_i_n_o_8ino.html#a602d2fccfb9f55d84f81b0c4d6f01589", null ],
    [ "aun_red_buffer", "_r_d117___a_r_d_u_i_n_o_8ino.html#aac1c23af668ef1d6750bfd4a5f6422fe", null ],
    [ "ch_hr_valid", "_r_d117___a_r_d_u_i_n_o_8ino.html#a43fb8ea97a26647405ca359095323280", null ],
    [ "ch_spo2_valid", "_r_d117___a_r_d_u_i_n_o_8ino.html#a2518324dce002f592cf6d7f0b1ad9024", null ],
    [ "n_heart_rate", "_r_d117___a_r_d_u_i_n_o_8ino.html#a3171c70bfa71c3a4f960bf3e8203d13f", null ],
    [ "n_ir_buffer_length", "_r_d117___a_r_d_u_i_n_o_8ino.html#ac16b6dd0e762f0ccc30e7102f97260d6", null ],
    [ "n_spo2", "_r_d117___a_r_d_u_i_n_o_8ino.html#a54d8056bd9812e0b8f73f911dcc21dfd", null ],
    [ "uch_dummy", "_r_d117___a_r_d_u_i_n_o_8ino.html#ac5e493da8cbdd1414d56e8f08282fcc2", null ]
];