var dir_19b53f07f52837a342947cc20e6d978f =
[
    [ "algorithm.cpp", "algorithm_8cpp.html", "algorithm_8cpp" ],
    [ "algorithm.h", "algorithm_8h.html", "algorithm_8h" ]
];