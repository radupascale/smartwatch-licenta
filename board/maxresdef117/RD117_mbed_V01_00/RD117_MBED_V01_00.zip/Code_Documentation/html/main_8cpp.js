var main_8cpp =
[
    [ "MAX_BRIGHTNESS", "main_8cpp.html#a2134a5a06f0865c945543a1f07eba387", null ],
    [ "main", "main_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4", null ],
    [ "pc", "main_8cpp.html#a81e0624d7e9f10f8f7e52a569ba24753", null ],
    [ "aun_ir_buffer", "main_8cpp.html#a07a24850120a56110cc2838d0afcafcf", null ],
    [ "aun_red_buffer", "main_8cpp.html#a85d1012c3814f9e393e6ff8d84e56723", null ],
    [ "ch_hr_valid", "main_8cpp.html#a43fb8ea97a26647405ca359095323280", null ],
    [ "ch_spo2_valid", "main_8cpp.html#a2518324dce002f592cf6d7f0b1ad9024", null ],
    [ "n_heart_rate", "main_8cpp.html#a3171c70bfa71c3a4f960bf3e8203d13f", null ],
    [ "n_ir_buffer_length", "main_8cpp.html#ac16b6dd0e762f0ccc30e7102f97260d6", null ],
    [ "n_sp02", "main_8cpp.html#a786e6c57c793d9af51360154ef90eb93", null ],
    [ "uch_dummy", "main_8cpp.html#ac5e493da8cbdd1414d56e8f08282fcc2", null ]
];