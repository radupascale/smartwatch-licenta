var algorithm_8cpp =
[
    [ "maxim_find_peaks", "algorithm_8cpp.html#a2a4e5ddbe0e04c48b166f2ff176667a9", null ],
    [ "maxim_heart_rate_and_oxygen_saturation", "algorithm_8cpp.html#a62050365673e666cd0d661a3664c26e6", null ],
    [ "maxim_peaks_above_min_height", "algorithm_8cpp.html#aab95338e44281c269f0b9b0f529741bf", null ],
    [ "maxim_remove_close_peaks", "algorithm_8cpp.html#adc6be68be81530d67a25c1a9905bec3a", null ],
    [ "maxim_sort_ascend", "algorithm_8cpp.html#a6cae46e51640b712afc2ebeefd2d51ff", null ],
    [ "maxim_sort_indices_descend", "algorithm_8cpp.html#a44b6312f81810d4deb64071d12ab0060", null ]
];