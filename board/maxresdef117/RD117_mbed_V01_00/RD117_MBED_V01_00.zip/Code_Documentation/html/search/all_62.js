var searchData=
[
  ['buffer_5fsize',['BUFFER_SIZE',['../algorithm_8h.html#a6b20d41d6252e9871430c242cb1a56e7',1,'algorithm.h']]]
];
