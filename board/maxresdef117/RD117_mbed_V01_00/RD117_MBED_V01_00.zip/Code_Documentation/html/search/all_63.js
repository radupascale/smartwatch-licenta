var searchData=
[
  ['ch_5fhr_5fvalid',['ch_hr_valid',['../main_8cpp.html#a43fb8ea97a26647405ca359095323280',1,'main.cpp']]],
  ['ch_5fspo2_5fvalid',['ch_spo2_valid',['../main_8cpp.html#a2518324dce002f592cf6d7f0b1ad9024',1,'main.cpp']]]
];
