var searchData=
[
  ['hamming_5fsize',['HAMMING_SIZE',['../algorithm_8h.html#a35be9e52c9110f5d91a4064e2f7b73c8',1,'algorithm.h']]],
  ['hr_5ffifo_5fsize',['HR_FIFO_SIZE',['../algorithm_8h.html#aa03906cc2e2d27ef4f3fa4db4312b524',1,'algorithm.h']]]
];
