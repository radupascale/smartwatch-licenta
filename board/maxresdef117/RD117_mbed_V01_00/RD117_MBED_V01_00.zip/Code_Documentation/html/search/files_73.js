var searchData=
[
  ['softi2cmaster_2eh',['SoftI2CMaster.h',['../_soft_i2_c_master_8h.html',1,'']]]
];
