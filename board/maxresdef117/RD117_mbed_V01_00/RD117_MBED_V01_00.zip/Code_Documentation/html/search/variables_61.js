var searchData=
[
  ['aun_5fir_5fbuffer',['aun_ir_buffer',['../main_8cpp.html#a07a24850120a56110cc2838d0afcafcf',1,'main.cpp']]],
  ['aun_5fred_5fbuffer',['aun_red_buffer',['../main_8cpp.html#a85d1012c3814f9e393e6ff8d84e56723',1,'main.cpp']]],
  ['auw_5fhamm',['auw_hamm',['../algorithm_8h.html#a1c25ffb675bce0db6a32fbf6ad514929',1,'algorithm.h']]]
];
