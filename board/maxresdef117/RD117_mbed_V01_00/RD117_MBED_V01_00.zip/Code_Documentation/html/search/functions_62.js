var searchData=
[
  ['begin',['begin',['../class_adafruit___neo_pixel.html#aad78931e44ce43c9b9c460dba7c9bbb7',1,'Adafruit_NeoPixel']]]
];
