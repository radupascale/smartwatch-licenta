var searchData=
[
  ['i2c',['i2c',['../_m_a_x30102_8cpp.html#ae3e7ab47cd5395225bf7c67b8ee84976',1,'MAX30102.cpp']]]
];
