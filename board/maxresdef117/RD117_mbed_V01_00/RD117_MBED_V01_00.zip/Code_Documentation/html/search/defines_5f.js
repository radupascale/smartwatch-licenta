var searchData=
[
  ['_5f_5ftmp_5freg_5f_5f',['__tmp_reg__',['../_soft_i2_c_master_8h.html#a0e6fc492b674d6ccceccb06e3bbf907b',1,'SoftI2CMaster.h']]],
  ['_5fsofti2c_5fh',['_SOFTI2C_H',['../_soft_i2_c_master_8h.html#a3bf497cc1d59d184775241e80a21085e',1,'SoftI2CMaster.h']]]
];
