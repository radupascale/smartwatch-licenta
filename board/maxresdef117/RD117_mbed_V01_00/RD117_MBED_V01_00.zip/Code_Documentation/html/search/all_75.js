var searchData=
[
  ['uch_5fdummy',['uch_dummy',['../main_8cpp.html#ac5e493da8cbdd1414d56e8f08282fcc2',1,'main.cpp']]],
  ['uch_5fspo2_5ftable',['uch_spo2_table',['../algorithm_8h.html#adfeeb6b08271807492803acc50347108',1,'algorithm.h']]]
];
