var searchData=
[
  ['i2c',['i2c',['../_m_a_x30102_8cpp.html#ae3e7ab47cd5395225bf7c67b8ee84976',1,'MAX30102.cpp']]],
  ['i2c_5fread_5faddr',['I2C_READ_ADDR',['../_m_a_x30102_8h.html#a11a0148c64950f3315f38d957cd43d37',1,'MAX30102.h']]],
  ['i2c_5fwrite_5faddr',['I2C_WRITE_ADDR',['../_m_a_x30102_8h.html#a7978167075eb8954c1090fc7ce9647c6',1,'MAX30102.h']]]
];
