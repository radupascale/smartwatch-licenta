var searchData=
[
  ['n_5fheart_5frate',['n_heart_rate',['../main_8cpp.html#a3171c70bfa71c3a4f960bf3e8203d13f',1,'main.cpp']]],
  ['n_5fir_5fbuffer_5flength',['n_ir_buffer_length',['../main_8cpp.html#ac16b6dd0e762f0ccc30e7102f97260d6',1,'main.cpp']]],
  ['n_5fsp02',['n_sp02',['../main_8cpp.html#a786e6c57c793d9af51360154ef90eb93',1,'main.cpp']]]
];
