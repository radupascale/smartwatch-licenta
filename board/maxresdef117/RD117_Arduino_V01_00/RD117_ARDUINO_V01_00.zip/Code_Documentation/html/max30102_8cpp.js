var max30102_8cpp =
[
    [ "maxim_max30102_init", "max30102_8cpp.html#a4113aeee76935425d8a557a79a4193df", null ],
    [ "maxim_max30102_read_fifo", "max30102_8cpp.html#a483073cbc9dbb7a5a2495ce2ae4fb968", null ],
    [ "maxim_max30102_read_reg", "max30102_8cpp.html#a0cd2c5a58e57ebbe8c9361384798331f", null ],
    [ "maxim_max30102_reset", "max30102_8cpp.html#a1df3bb178b66379a2975c56395c47d9b", null ],
    [ "maxim_max30102_write_reg", "max30102_8cpp.html#a4c2ec1539c1ec8354cdaefe2c3bf48d6", null ]
];