var searchData=
[
  ['ma4_5fsize',['MA4_SIZE',['../algorithm_8h.html#af8c3cbac49a22022b17cc7b34d42cbae',1,'algorithm.h']]],
  ['max_5fbrightness',['MAX_BRIGHTNESS',['../_r_d117___a_r_d_u_i_n_o_8ino.html#a2134a5a06f0865c945543a1f07eba387',1,'RD117_ARDUINO.ino']]],
  ['min',['min',['../algorithm_8h.html#abb702d8b501669a23aa0ab3b281b9384',1,'algorithm.h']]]
];
