var searchData=
[
  ['canshow',['canShow',['../class_adafruit___neo_pixel.html#ad38ce8112667b70ad7c411a98892af0e',1,'Adafruit_NeoPixel']]],
  ['ch_5fhr_5fvalid',['ch_hr_valid',['../_r_d117___a_r_d_u_i_n_o_8ino.html#a43fb8ea97a26647405ca359095323280',1,'RD117_ARDUINO.ino']]],
  ['ch_5fspo2_5fvalid',['ch_spo2_valid',['../_r_d117___a_r_d_u_i_n_o_8ino.html#a2518324dce002f592cf6d7f0b1ad9024',1,'RD117_ARDUINO.ino']]],
  ['clear',['clear',['../class_adafruit___neo_pixel.html#ac8bb3912a3ce86b15842e79d0b421204',1,'Adafruit_NeoPixel']]],
  ['color',['Color',['../class_adafruit___neo_pixel.html#ae3e6c2fabbee89d19487424acd8d9fec',1,'Adafruit_NeoPixel::Color(uint8_t r, uint8_t g, uint8_t b)'],['../class_adafruit___neo_pixel.html#a9846704aaabd4e102beba5a5484d5738',1,'Adafruit_NeoPixel::Color(uint8_t r, uint8_t g, uint8_t b, uint8_t w)']]]
];
