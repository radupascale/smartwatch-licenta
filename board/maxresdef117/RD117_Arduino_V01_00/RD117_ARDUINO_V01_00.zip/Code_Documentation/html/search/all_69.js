var searchData=
[
  ['i2c_5fcpufreq',['I2C_CPUFREQ',['../_soft_i2_c_master_8h.html#a9e64b8013968d3d107154c4044643481',1,'SoftI2CMaster.h']]],
  ['i2c_5fdelay_5fcounter',['I2C_DELAY_COUNTER',['../_soft_i2_c_master_8h.html#a2af652afc14dc884cb2b42683d45c8df',1,'SoftI2CMaster.h']]],
  ['i2c_5fdelay_5fhalf',['i2c_delay_half',['../_soft_i2_c_master_8h.html#a2ccdf1a08647bd236d7988a794dc403c',1,'SoftI2CMaster.h']]],
  ['i2c_5ffastmode',['I2C_FASTMODE',['../_soft_i2_c_master_8h.html#a954e80e3d9812f381eb05af7e7081cc2',1,'SoftI2CMaster.h']]],
  ['i2c_5finit',['i2c_init',['../_soft_i2_c_master_8h.html#ad5dc48c57198db1ee444a61405d2ea3d',1,'SoftI2CMaster.h']]],
  ['i2c_5fmax_5fstretch',['I2C_MAX_STRETCH',['../_soft_i2_c_master_8h.html#a970e76c45294e29445ecbf139e6c386a',1,'SoftI2CMaster.h']]],
  ['i2c_5fnointerrupt',['I2C_NOINTERRUPT',['../_soft_i2_c_master_8h.html#a206ca6aa556565db88a5302050eb3936',1,'SoftI2CMaster.h']]],
  ['i2c_5fread',['I2C_READ',['../_soft_i2_c_master_8h.html#ab5c0fbe837494c5f9130a5914854250d',1,'I2C_READ():&#160;SoftI2CMaster.h'],['../_soft_i2_c_master_8h.html#a717c8440b070832a7d3375cfd5a526ef',1,'i2c_read(bool last):&#160;SoftI2CMaster.h']]],
  ['i2c_5fread_5faddr',['I2C_READ_ADDR',['../max30102_8h.html#a11a0148c64950f3315f38d957cd43d37',1,'max30102.h']]],
  ['i2c_5frep_5fstart',['i2c_rep_start',['../_soft_i2_c_master_8h.html#a68105c3bb259544bcc000c21b8e5d355',1,'SoftI2CMaster.h']]],
  ['i2c_5fslowmode',['I2C_SLOWMODE',['../_soft_i2_c_master_8h.html#a0e1c9e6ca00fe824f98e8b7310589f5f',1,'SoftI2CMaster.h']]],
  ['i2c_5fstart',['i2c_start',['../_soft_i2_c_master_8h.html#a876a5d83cf8b5fa662b04a81657d8d30',1,'SoftI2CMaster.h']]],
  ['i2c_5fstart_5fwait',['i2c_start_wait',['../_soft_i2_c_master_8h.html#a5e2e89e9b3cb2a075d3d46bb148a42e9',1,'SoftI2CMaster.h']]],
  ['i2c_5fstop',['i2c_stop',['../_soft_i2_c_master_8h.html#ad35d4e4f52ca74b503d5e5e1e0a3f5f3',1,'SoftI2CMaster.h']]],
  ['i2c_5ftimeout',['I2C_TIMEOUT',['../_soft_i2_c_master_8h.html#afa3215f0aa766367f5d34bee80929152',1,'SoftI2CMaster.h']]],
  ['i2c_5ftimeout_5fdelay_5floops',['I2C_TIMEOUT_DELAY_LOOPS',['../_soft_i2_c_master_8h.html#ae704dfa4c0384f5d618fbfd14e0dec80',1,'SoftI2CMaster.h']]],
  ['i2c_5fwait_5fscl_5fhigh',['i2c_wait_scl_high',['../_soft_i2_c_master_8h.html#a55c46a9ce2c4eaec0c5878436a4a6b5b',1,'SoftI2CMaster.h']]],
  ['i2c_5fwrite',['I2C_WRITE',['../_soft_i2_c_master_8h.html#a9536bf85bced4f4e549a82fb18eb6140',1,'I2C_WRITE():&#160;SoftI2CMaster.h'],['../_soft_i2_c_master_8h.html#a5abe73d680cae254aafa5227e6d87a13',1,'i2c_write(uint8_t value):&#160;SoftI2CMaster.h']]],
  ['i2c_5fwrite_5faddr',['I2C_WRITE_ADDR',['../max30102_8h.html#a7978167075eb8954c1090fc7ce9647c6',1,'max30102.h']]]
];
