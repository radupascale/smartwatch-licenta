var searchData=
[
  ['aun_5fir_5fbuffer',['aun_ir_buffer',['../_r_d117___a_r_d_u_i_n_o_8ino.html#a602d2fccfb9f55d84f81b0c4d6f01589',1,'RD117_ARDUINO.ino']]],
  ['aun_5fred_5fbuffer',['aun_red_buffer',['../_r_d117___a_r_d_u_i_n_o_8ino.html#aac1c23af668ef1d6750bfd4a5f6422fe',1,'RD117_ARDUINO.ino']]]
];
