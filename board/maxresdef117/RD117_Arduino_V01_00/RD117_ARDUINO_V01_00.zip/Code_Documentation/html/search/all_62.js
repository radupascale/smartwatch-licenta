var searchData=
[
  ['begin',['begin',['../class_adafruit___neo_pixel.html#aad78931e44ce43c9b9c460dba7c9bbb7',1,'Adafruit_NeoPixel']]],
  ['buffer_5fsize',['BUFFER_SIZE',['../algorithm_8h.html#a6b20d41d6252e9871430c242cb1a56e7',1,'algorithm.h']]]
];
