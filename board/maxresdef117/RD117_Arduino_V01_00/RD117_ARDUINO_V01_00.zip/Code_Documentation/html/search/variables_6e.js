var searchData=
[
  ['n_5fheart_5frate',['n_heart_rate',['../_r_d117___a_r_d_u_i_n_o_8ino.html#a3171c70bfa71c3a4f960bf3e8203d13f',1,'RD117_ARDUINO.ino']]],
  ['n_5fir_5fbuffer_5flength',['n_ir_buffer_length',['../_r_d117___a_r_d_u_i_n_o_8ino.html#ac16b6dd0e762f0ccc30e7102f97260d6',1,'RD117_ARDUINO.ino']]],
  ['n_5fspo2',['n_spo2',['../_r_d117___a_r_d_u_i_n_o_8ino.html#a54d8056bd9812e0b8f73f911dcc21dfd',1,'RD117_ARDUINO.ino']]]
];
