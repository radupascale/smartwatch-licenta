var searchData=
[
  ['i2c_5fcpufreq',['I2C_CPUFREQ',['../_soft_i2_c_master_8h.html#a9e64b8013968d3d107154c4044643481',1,'SoftI2CMaster.h']]],
  ['i2c_5fdelay_5fcounter',['I2C_DELAY_COUNTER',['../_soft_i2_c_master_8h.html#a2af652afc14dc884cb2b42683d45c8df',1,'SoftI2CMaster.h']]],
  ['i2c_5ffastmode',['I2C_FASTMODE',['../_soft_i2_c_master_8h.html#a954e80e3d9812f381eb05af7e7081cc2',1,'SoftI2CMaster.h']]],
  ['i2c_5fmax_5fstretch',['I2C_MAX_STRETCH',['../_soft_i2_c_master_8h.html#a970e76c45294e29445ecbf139e6c386a',1,'SoftI2CMaster.h']]],
  ['i2c_5fnointerrupt',['I2C_NOINTERRUPT',['../_soft_i2_c_master_8h.html#a206ca6aa556565db88a5302050eb3936',1,'SoftI2CMaster.h']]],
  ['i2c_5fread',['I2C_READ',['../_soft_i2_c_master_8h.html#ab5c0fbe837494c5f9130a5914854250d',1,'SoftI2CMaster.h']]],
  ['i2c_5fread_5faddr',['I2C_READ_ADDR',['../max30102_8h.html#a11a0148c64950f3315f38d957cd43d37',1,'max30102.h']]],
  ['i2c_5fslowmode',['I2C_SLOWMODE',['../_soft_i2_c_master_8h.html#a0e1c9e6ca00fe824f98e8b7310589f5f',1,'SoftI2CMaster.h']]],
  ['i2c_5ftimeout',['I2C_TIMEOUT',['../_soft_i2_c_master_8h.html#afa3215f0aa766367f5d34bee80929152',1,'SoftI2CMaster.h']]],
  ['i2c_5ftimeout_5fdelay_5floops',['I2C_TIMEOUT_DELAY_LOOPS',['../_soft_i2_c_master_8h.html#ae704dfa4c0384f5d618fbfd14e0dec80',1,'SoftI2CMaster.h']]],
  ['i2c_5fwrite',['I2C_WRITE',['../_soft_i2_c_master_8h.html#a9536bf85bced4f4e549a82fb18eb6140',1,'SoftI2CMaster.h']]],
  ['i2c_5fwrite_5faddr',['I2C_WRITE_ADDR',['../max30102_8h.html#a7978167075eb8954c1090fc7ce9647c6',1,'max30102.h']]]
];
