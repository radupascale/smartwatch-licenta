var searchData=
[
  ['updatelength',['updateLength',['../class_adafruit___neo_pixel.html#a05542d574f1a9a73f9e3547990321944',1,'Adafruit_NeoPixel']]],
  ['updatetype',['updateType',['../class_adafruit___neo_pixel.html#a65e59263e0f5a04c7202d4385d3a539b',1,'Adafruit_NeoPixel']]]
];
