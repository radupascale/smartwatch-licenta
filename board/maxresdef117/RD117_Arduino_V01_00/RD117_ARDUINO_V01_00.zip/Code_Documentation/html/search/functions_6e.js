var searchData=
[
  ['numpixels',['numPixels',['../class_adafruit___neo_pixel.html#ac893a5c07c41604539022af84665c04b',1,'Adafruit_NeoPixel']]]
];
