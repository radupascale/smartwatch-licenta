var searchData=
[
  ['ch_5fhr_5fvalid',['ch_hr_valid',['../_r_d117___a_r_d_u_i_n_o_8ino.html#a43fb8ea97a26647405ca359095323280',1,'RD117_ARDUINO.ino']]],
  ['ch_5fspo2_5fvalid',['ch_spo2_valid',['../_r_d117___a_r_d_u_i_n_o_8ino.html#a2518324dce002f592cf6d7f0b1ad9024',1,'RD117_ARDUINO.ino']]]
];
