var searchData=
[
  ['adafruit_5fneopixel',['Adafruit_NeoPixel',['../class_adafruit___neo_pixel.html#ac314debe6917c8c9b320b785139c6e58',1,'Adafruit_NeoPixel::Adafruit_NeoPixel(uint16_t n, uint8_t p=6, neoPixelType t=NEO_GRB+NEO_KHZ800)'],['../class_adafruit___neo_pixel.html#ab1ac0c48cf3fd9185e40308c37f1d320',1,'Adafruit_NeoPixel::Adafruit_NeoPixel(void)']]]
];
