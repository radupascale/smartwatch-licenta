var searchData=
[
  ['uch_5fdummy',['uch_dummy',['../_r_d117___a_r_d_u_i_n_o_8ino.html#ac5e493da8cbdd1414d56e8f08282fcc2',1,'RD117_ARDUINO.ino']]],
  ['uch_5fspo2_5ftable',['uch_spo2_table',['../algorithm_8h.html#adfeeb6b08271807492803acc50347108',1,'algorithm.h']]]
];
