var algorithm_8h =
[
    [ "BUFFER_SIZE", "algorithm_8h.html#a6b20d41d6252e9871430c242cb1a56e7", null ],
    [ "false", "algorithm_8h.html#a65e9886d74aaee76545e83dd09011727", null ],
    [ "FS", "algorithm_8h.html#a30588c5eca7c9cb6ebba02a0236f0119", null ],
    [ "MA4_SIZE", "algorithm_8h.html#af8c3cbac49a22022b17cc7b34d42cbae", null ],
    [ "min", "algorithm_8h.html#abb702d8b501669a23aa0ab3b281b9384", null ],
    [ "true", "algorithm_8h.html#a41f9c5fb8b08eb5dc3edce4dcb37fee7", null ],
    [ "maxim_find_peaks", "algorithm_8h.html#ab0180596dbe4f711c2e5b6c637ca3549", null ],
    [ "maxim_heart_rate_and_oxygen_saturation", "algorithm_8h.html#a62050365673e666cd0d661a3664c26e6", null ],
    [ "maxim_peaks_above_min_height", "algorithm_8h.html#a1c5af43429e2848c106cb3080b72e837", null ],
    [ "maxim_remove_close_peaks", "algorithm_8h.html#adc6be68be81530d67a25c1a9905bec3a", null ],
    [ "maxim_sort_ascend", "algorithm_8h.html#a6cae46e51640b712afc2ebeefd2d51ff", null ],
    [ "maxim_sort_indices_descend", "algorithm_8h.html#a44b6312f81810d4deb64071d12ab0060", null ],
    [ "an_x", "algorithm_8h.html#a7d4e0b0915b58092f3b4bb2fbd252f3f", null ],
    [ "an_y", "algorithm_8h.html#a72c76142c07186ae6d7200ec3c9a4f76", null ],
    [ "uch_spo2_table", "algorithm_8h.html#adfeeb6b08271807492803acc50347108", null ]
];